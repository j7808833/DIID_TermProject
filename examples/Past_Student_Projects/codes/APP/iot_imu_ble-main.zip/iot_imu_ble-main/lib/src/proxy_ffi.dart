export 'package:web_ffi/web_ffi.dart' if (dart.library.ffi) 'dart:ffi';
