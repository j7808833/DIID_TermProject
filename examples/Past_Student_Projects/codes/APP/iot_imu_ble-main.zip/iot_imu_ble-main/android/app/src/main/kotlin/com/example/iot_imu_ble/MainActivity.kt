package com.example.iot_imu_ble

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
